I used Python.
How to run:
py my-dvr.py

or 

python3 my-dvr.py

The network.txt must be in the same directory with my-dvr.py


First network (output1.txt):
0 2 0 0 1
2 0 5 0 0
0 5 0 4 0
0 0 4 0 1
1 0 0 1 0

Second network (output2.txt):
0 10 10 10 10
10 0 0 0 0
10 0 0 0 0
10 0 0 0 0
10 0 0 0 0